/* Zümrüt Plastik 360° görüntüleyici — tek ürün kilitli sürüm
   Sadece ZP360_ALLOWED_PATHS içindeki ürün sayfasında devreye girer.
   Diğer sayfalarda CSS eklemez, görsel yüklemez; sadece sayfa adresini kontrol eder. */
(function () {
  var ZP360_ALLOWED_PATHS = [
    '/22-litre-market-alisveris-sepeti'
  ];
  function ok() {
    var p = (location.pathname || '/').replace(/\/+$/, '').toLowerCase();
    return ZP360_ALLOWED_PATHS.some(function (a) { return p === String(a).replace(/\/+$/, '').toLowerCase(); });
  }
  var started = false, timer = null;
  var viewer = (function () {
  var C = '#1f5fd6';
  var css = [
    '.zp360{--zp-a:' + C + ';position:relative;width:100%;max-width:1100px;margin:0 auto;font:15px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#2a2c30;user-select:none;-webkit-user-select:none}',
    '.zp-stage{position:relative;aspect-ratio:3/2;background:linear-gradient(#edebe7 0%,#e6e3dd 25%,#e5e1dc 50%,#ddd8d0 75%,#dad5cf 100%);border-radius:10px;overflow:hidden;cursor:grab;touch-action:pan-y}',
    '.zp-stage:focus-visible{outline:3px solid var(--zp-a);outline-offset:2px}',
    '.zp360.zp-drag .zp-stage{cursor:grabbing}.zp360.zp-zoomed .zp-stage{cursor:move;touch-action:none}',
    '.zp-view{position:absolute;inset:0;transition:transform .25s ease}.zp-drag .zp-view{transition:none}',
    '.zp-f{position:absolute;left:50%;top:50%;height:100%;-webkit-mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent);mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent);aspect-ratio:1/1;transform:translate(-50%,-50%);object-fit:contain;pointer-events:none}',
    '.zp-head{position:absolute;top:3.5%;left:50%;transform:translateX(-50%);text-align:center;pointer-events:none;transition:opacity .4s}',
    '.zp-head svg{width:clamp(90px,12vw,170px);height:auto;display:block;margin:0 auto}',
    '.zp-head span{display:block;margin-top:.2em;font-size:clamp(13px,1.7vw,24px);font-weight:500;color:#2a2c30}',
    '.zp-arr{position:absolute;top:44%;width:clamp(38px,6vw,90px);opacity:.95;pointer-events:none;transition:opacity .4s}',
    '.zp-arr.l{left:14.5%}.zp-arr.r{right:14.5%}',
    '.zp-used .zp-arr,.zp-used .zp-head{opacity:0}',
    '.zp-help{position:absolute;left:1.2%;top:50%;transform:translateY(-50%);background:rgba(244,243,241,.92);border-radius:12px;padding:6px 14px;width:118px;box-shadow:0 1px 6px rgba(0,0,0,.05)}',
    '.zp-help div{display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 0;text-align:center;font-size:13px;color:#33363b}',
    '.zp-help div+div{border-top:1px solid #dcdad6}.zp-help svg{width:34px;height:34px}',
    '.zp-tools{position:absolute;right:1.2%;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:14px}',
    '.zp-tools button{width:46px;height:46px;border-radius:50%;border:0;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.12);display:grid;place-items:center;cursor:pointer;color:#26282c;padding:0}',
    '.zp-tools button:hover{background:#f2f5fc}.zp-tools button:focus-visible,.zp-th:focus-visible{outline:3px solid var(--zp-a);outline-offset:2px}',
    '.zp-tools svg{width:22px;height:22px}',
    '.zp-logo{position:absolute;right:1.5%;bottom:2%;width:20%;max-width:200px;pointer-events:none}',
    '.zp-load{position:absolute;left:0;bottom:0;height:3px;background:var(--zp-a);transition:width .2s}',
    '.zp-strip{display:flex;gap:12px;margin-top:14px;overflow-x:auto;padding:4px 2px;scrollbar-width:thin}',
    '.zp-th{flex:1 0 84px;max-width:132px;aspect-ratio:4/3;border-radius:10px;border:2px solid transparent;background:#e6e3dd;box-shadow:0 1px 4px rgba(0,0,0,.08);padding:2px;cursor:pointer}',
    '.zp-th img{width:100%;height:100%;object-fit:cover;border-radius:6px;display:block;pointer-events:none}',
    '.zp-th[aria-current="true"]{border-color:var(--zp-a)}',
    '.zp-range{display:block;width:72%;margin:14px auto 0;-webkit-appearance:none;appearance:none;height:4px;border-radius:2px;background:linear-gradient(var(--zp-a),var(--zp-a)) 0/var(--p,0%) 100% no-repeat,#d6d8dc;outline:none}',
    '.zp-range::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--zp-a);border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.25);cursor:pointer}',
    '.zp-range::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:var(--zp-a);border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.25);cursor:pointer}',
    '.zp360:fullscreen{max-width:none;background:#ecebe8;display:flex;flex-direction:column;justify-content:center;padding:2vh 2vw;box-sizing:border-box}',
    '.zp360:fullscreen .zp-stage{flex:1;aspect-ratio:auto}',
    '@media (max-width:700px){.zp-help{display:none}.zp-stage{aspect-ratio:1/1}.zp-f{height:100%;top:50%}.zp-arr{display:none}.zp-head{top:2%;white-space:nowrap}.zp-head svg{width:80px}.zp-head span{font-size:12px}.zp-f{height:92%!important;top:56%!important}.zp-tools button{width:38px;height:38px}.zp-tools{gap:10px}.zp-th{flex-basis:70px}.zp-range{width:90%}.zp-logo{width:30%}}'
  ].join('');
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var I = {
    head: '<svg viewBox="0 0 170 80" fill="none" stroke="#2a2c30" stroke-width="5" stroke-linecap="round" aria-hidden="true"><text x="85" y="40" text-anchor="middle" fill="#2a2c30" stroke="none" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-weight="700" font-size="42">360°</text><path d="M38 28C14 34 6 46 22 56c14 8 40 12 60 12"/><path d="M132 28c24 6 32 18 16 28-10 6-26 10-44 11"/><path d="M76 60l10 8-10 8"/></svg>',
    arrL: '<svg class="zp-arr l" viewBox="0 0 90 120" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="filter:drop-shadow(0 2px 4px rgba(0,0,0,.18))"><path d="M62 10C20 30 8 70 52 100"/><path d="M30 100h26V74"/></svg>',
    arrR: '<svg class="zp-arr r" viewBox="0 0 90 120" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="filter:drop-shadow(0 2px 4px rgba(0,0,0,.18))"><path d="M28 10c42 20 54 60 10 90"/><path d="M60 100H34V74"/></svg>',
    mouse: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="6" y="2.5" width="12" height="19" rx="6"/><path d="M12 2.5v7M6 9.5h6"/></svg>',
    hand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11V4.5a1.5 1.5 0 0 1 3 0V11m0-1.5a1.5 1.5 0 0 1 3 0V11m0-.5a1.5 1.5 0 0 1 3 0V15a6 6 0 0 1-6 6h-1a6 6 0 0 1-4.6-2.2L4 15.5a1.6 1.6 0 0 1 2.4-2L9 15.5"/><path d="M7 4.5a4 4 0 0 1 7 0"/></svg>',
    spin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3"/><path d="M18 2.5v4.2h-4.2M6 21.5v-4.2h4.2"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M5 12h14"/></svg>',
    full: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/></svg>'
  };
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function init(el) {
    var fv = el.dataset.framesVar, base = el.dataset.base, ext = el.dataset.ext || '.webp';
    var n = fv ? window[fv].length : (+el.dataset.count || 36), nt = Math.min(+el.dataset.thumbs || 10, n);
    var sens = +el.dataset.sensitivity || 8, auto = el.dataset.autoplay !== 'false';
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var srcs = []; for (var i = 1; i <= n; i++) srcs.push(fv ? window[fv][i - 1] : base + pad(i) + ext);

    el.innerHTML =
      '<div class="zp-stage" tabindex="0" role="img" aria-label="' + (el.dataset.label || 'Ürünün 360° görünümü') + '. Sürükleyin veya ok tuşlarını kullanın.">' +
        '<div class="zp-view"><img class="zp-f" alt="" draggable="false"></div>' +
        '<div class="zp-head">' + I.head + '<span>Sürükleyerek ürünü döndürün</span></div>' + I.arrL + I.arrR +
        '<div class="zp-help"><div>' + I.mouse + 'Mouse ile sürükleyin</div><div>' + I.hand + 'Parmağınızla çevirin</div><div>' + I.spin + '360° Görüntüleyin</div></div>' +
        '<div class="zp-tools"><button type="button" data-z="1" aria-label="Yakınlaştır">' + I.plus + '</button><button type="button" data-z="-1" aria-label="Uzaklaştır">' + I.minus + '</button><button type="button" data-fs aria-label="Tam ekran">' + I.full + '</button></div>' +
        (el.dataset.logo ? '<img class="zp-logo" alt="Zümrüt Plastik" src="' + el.dataset.logo + '">' : '') +
        '<div class="zp-load" style="width:0"></div>' +
      '</div><div class="zp-strip" role="group" aria-label="Açılar"></div>' +
      '<input class="zp-range" type="range" min="0" max="' + (n - 1) + '" value="0" aria-label="Dönüş açısı">';

    var stage = el.querySelector('.zp-stage'), view = el.querySelector('.zp-view'), img = el.querySelector('.zp-f');
    var strip = el.querySelector('.zp-strip'), range = el.querySelector('.zp-range'), bar = el.querySelector('.zp-load');
    var thIdx = [], ths = [];
    for (var t = 0; t < nt; t++) {
      var k = Math.round(t * n / nt); thIdx.push(k);
      var b = document.createElement('button'); b.type = 'button'; b.className = 'zp-th'; b.setAttribute('aria-label', Math.round(k * 360 / n) + '° görünüm');
      b.innerHTML = '<img alt="" loading="lazy" src="' + srcs[k] + '">';
      (function (k) { b.onclick = function () { stop(); show(k); }; })(k);
      strip.appendChild(b); ths.push(b);
    }

    var cur = 0, timer = null, zoom = 1, px = 0, py = 0, loaded = 0;
    srcs.forEach(function (s) { var p = new Image(); p.onload = p.onerror = function () { loaded++; bar.style.width = loaded / n * 100 + '%'; if (loaded === n) { bar.remove(); start(); } }; p.src = s; });

    function show(i) {
      cur = ((i % n) + n) % n; img.src = srcs[cur]; range.value = cur; range.style.setProperty('--p', cur / (n - 1) * 100 + '%');
      var best = 0; thIdx.forEach(function (k, j) { if (Math.abs(k - cur) <= Math.abs(thIdx[best] - cur)) best = j; });
      ths.forEach(function (b, j) { b.setAttribute('aria-current', j === best ? 'true' : 'false'); });
    }
    function start() { if (auto && !reduce) timer = setInterval(function () { show(cur + 1); }, 90); }
    function stop() { if (timer) { clearInterval(timer); timer = null; } el.classList.add('zp-used'); }
    function applyZoom() {
      if (zoom === 1) px = py = 0;
      view.style.transform = 'translate(' + px + 'px,' + py + 'px) scale(' + zoom + ')';
      el.classList.toggle('zp-zoomed', zoom > 1);
    }
    show(0);

    var down = false, x0 = 0, y0 = 0, f0 = 0, px0 = 0, py0 = 0;
    stage.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;
      stop(); down = true; x0 = e.clientX; y0 = e.clientY; f0 = cur; px0 = px; py0 = py;
      el.classList.add('zp-drag'); stage.setPointerCapture(e.pointerId);
    });
    stage.addEventListener('pointermove', function (e) {
      if (!down) return;
      if (zoom > 1) { px = px0 + (e.clientX - x0); py = py0 + (e.clientY - y0); applyZoom(); }
      else show(f0 - Math.round((e.clientX - x0) / sens));
    });
    function up() { down = false; el.classList.remove('zp-drag'); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    stage.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { stop(); show(cur + 1); e.preventDefault(); }
      if (e.key === 'ArrowRight') { stop(); show(cur - 1); e.preventDefault(); }
    });
    range.addEventListener('input', function () { stop(); show(+range.value); });
    el.querySelectorAll('[data-z]').forEach(function (b) {
      b.onclick = function () { stop(); zoom = Math.max(1, Math.min(3, zoom + 0.5 * +b.dataset.z)); applyZoom(); };
    });
    el.querySelector('[data-fs]').onclick = function () {
      stop();
      if (document.fullscreenElement) document.exitFullscreen();
      else if (el.requestFullscreen) el.requestFullscreen();
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    };
  }
  function run() { document.querySelectorAll('.zp360:not([data-zp])').forEach(function (el) { el.dataset.zp = 1; init(el); }); }
  function boot() {
    run();
    // ikas sayfa değiştirirken yeniden yüklenmez; yeni eklenen görüntüleyicileri yakala
    new MutationObserver(function () { run(); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
});
  function check() {
    if (started || !ok()) return;
    started = true; if (timer) clearInterval(timer);
    viewer();
  }
  check();
  // ikas sayfa değiştirirken sayfayı yeniden yüklemez; ziyaretçi ürüne başka sayfadan gelirse yakala
  if (!started) { timer = setInterval(check, 800); window.addEventListener('popstate', check); }
})();
